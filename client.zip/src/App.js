import React from "react";
import QRCodeScanner from "./QRCodeScanner";
import "./App.css";

function App() {
  return (
    <div className="App">
      <QRCodeScanner />
    </div>
  );
}

export default App;
